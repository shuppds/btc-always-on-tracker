# BTC Scalp Forecast Terminal — Final package

This package contains the interactive browser terminal AND a scheduled GitHub Actions tracker.

## What's included
- `bot-dashboard.html` — full interactive BTC Scalp Forecast Terminal.
- `index.html` — cloud-tracker dashboard reading `data/tracker.json`.
- `tracker.py` — scheduled tracker that evaluates 15-minute BTC candle direction.
- `.github/workflows/track.yml` — GitHub Actions schedule (roughly every 5 minutes) and manual run button.
- `data/tracker.json` — stored cloud tracker history.
- `track.yml` — duplicate copy of the workflow file to make it easier to find/copy if Windows or GitHub hides `.github`.

## Important behavior in the interactive bot
- The Early Buy Snapshot cannot lock a direction during the first 3 minutes of a 15-minute candle.
- After 3 minutes, it continues waiting as long as needed until **Primary Forecast >= 80%, Scalp Score >= 80%, both agree on UP or DOWN, scalp entry confirmation has completed, and reversal-risk checks pass**.
- Once a qualifying direction appears, the snapshot locks that direction for the rest of the current 15-minute candle and will not flip during that candle. It resets at the next 15-minute candle.
- This lock is stored in browser local storage. The browser terminal itself must remain open to keep updating; the GitHub scheduled tracker is a separate, simpler process.
- The displayed scores are heuristic strength scores, not calibrated probabilities or guaranteed win rates.

## Easiest GitHub setup (Windows; no Python installation)

### A. Upload visible files first
1. Download and extract this ZIP.
2. Open your GitHub repository `btc-always-on-tracker`.
3. Choose **Add file → Upload files**.
4. Upload `README.md`, `index.html`, `bot-dashboard.html`, `tracker.py`, and the `data` folder. Commit the upload.
5. Do not worry if the upload screen skips `.github`; create the workflow manually in the next step.

### B. Create the workflow directly in GitHub (this avoids hidden-folder issues)
1. In the repository, click **Add file → Create new file**.
2. In the filename field at the top, type exactly: `.github/workflows/track.yml`.
3. Open the `track.yml` file located at the ROOT of the extracted package (not inside `.github`) in Notepad. Select all and copy it.
4. Paste the contents into GitHub's editor.
5. Scroll down to **Commit changes**, choose commit directly to `main`, and click **Commit changes**.
6. Open the repository's **Actions** tab. If asked, enable Actions. Choose **Update BTC tracker** on the left and click **Run workflow** → **Run workflow**.
7. Open the run. A green check means the job succeeded; a red X means it failed. Click the run and then the `Update tracker data` step to see any error.

### C. Publish the dashboard
1. Go to **Settings → Pages**.
2. Under Build and deployment, choose **Deploy from a branch**.
3. Choose branch `main`, folder `/(root)`, then Save.
4. Wait for GitHub Pages to publish. The cloud dashboard URL will be `https://YOUR-USERNAME.github.io/btc-always-on-tracker/`.
5. The interactive terminal URL will be `https://YOUR-USERNAME.github.io/btc-always-on-tracker/bot-dashboard.html`.

## How to tell it is working
- **Actions tab:** a recent run with a green check mark is the first sign the scheduled job ran successfully.
- **Repository `data/tracker.json`:** after a successful run, the `updated_at` field should change and new tracking data may appear.
- **Pages:** the URL appears under Settings → Pages once deployment finishes. Open it to see the cloud dashboard.
- GitHub scheduled jobs can be delayed and are not a tick-by-tick always-on service. The free workflow runs about every five minutes, so it can miss signals or phase boundaries. Do not treat the cloud tracker as a guaranteed real-time 0–3 minute tracker.

## Reset cloud history
On GitHub, open `data/tracker.json`, click the pencil icon, replace its contents with:

```json
{
  "updated_at": null,
  "source": "Binance BTCUSDT spot 15m candles",
  "early": [],
  "post_lock": [],
  "last_seen_closed": 0,
  "notes": "Scheduled cloud tracker. Signals are heuristic, not calibrated probabilities."
}
```

Commit the change. The next successful workflow run starts fresh.

## Limits
- This is paper tracking only; it does not place trades.
- The interactive terminal uses public Binance market data and needs the browser open to update live.
- GitHub Actions is scheduled, not a continuous streaming process. Its five-minute schedule cannot guarantee that every early call is recorded.
- The cloud `tracker.py` is a simpler heuristic and does not reproduce every live indicator or the interactive bot's dual-80% lock rule. Use `bot-dashboard.html` for the primary/scalp lock behavior.
