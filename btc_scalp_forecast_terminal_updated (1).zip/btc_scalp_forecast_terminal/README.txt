BTC SCALP FORECAST TERMINAL

Open index.html in Edge or Chrome. No Python or installation is required.

The visible Kalshi odds panel has been removed. The tracker still attempts to retrieve public Kalshi market data in the background because measuring whether a contract reaches 80 cents requires actual contract prices. Signal calls are recorded only when a matching contract ticker and usable price are available at call time. If public market data is blocked by browser/network restrictions, no new 80-cent tracker calls can be recorded; the app does not invent prices. Existing records that had no ticker are marked NO ODDS AT CALL rather than remaining pending forever.

Early Calls and Post-3-Minute Calls are tracked separately. Each tracked call is marked HIT if the observed matching-side contract price reaches 80 cents within its 15-minute observation window, otherwise MISS when the window ends. The browser must remain open and the public price feed must continue updating; missed ticks may not be recoverable. This is paper tracking, not a calibrated probability or a trading instruction.

Use Reset calls + hit rate to clear both trackers. History is stored locally in this browser.
