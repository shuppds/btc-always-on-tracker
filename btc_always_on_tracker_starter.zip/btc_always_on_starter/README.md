# Always-on BTC tracker starter (free-tier, scheduled)

This starter uses **GitHub Actions** to run a Python tracker in the cloud every 5 minutes, even when your PC is off, and **GitHub Pages** to show a simple dashboard. Python runs on GitHub's runner; you do not install Python on your Windows computer.

## Important limitations
- This is scheduled tracking, **not a continuously running 24/7 process**. GitHub Actions cron can be delayed, and 5-minute runs can miss short-lived price changes. Do not treat it as a tick-perfect audit log.
- The example cloud tracker uses a simple transparent momentum heuristic from Binance BTCUSDT candles. It is not the same as the full browser dashboard's order-book calculations, and its scores are not calibrated probabilities.
- It compares the final close of the same 15-minute candle with that candle's open. Flat candles are excluded from hit-rate denominator.
- GitHub free usage/feature availability can change. Public repositories are the simplest route for scheduled Actions; keep secrets out of this repository. Check current GitHub plan limits before relying on it.
- The old `local-dashboard.html` is included for reference only; it uses browser-local storage and is not connected to the cloud history. Use `index.html` for cloud results.

## Setup (no local Python needed)
1. Create a GitHub account at https://github.com/ if you don't already have one.
2. Create a **public** repository named `btc-always-on-tracker`.
3. Upload the contents of this ZIP to the repository root, including the `.github/workflows/track.yml` file. Make sure GitHub includes the hidden `.github` folder.
4. Open **Actions** in the repository and enable workflows if GitHub prompts you.
5. Open **Update BTC tracker** under Actions, choose **Run workflow** once to seed `data/tracker.json`. If it fails, open the run and read the log.
6. In repository **Settings → Pages**, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
7. After Pages finishes deploying, open the URL shown in Settings → Pages. It should look like `https://YOUR-USERNAME.github.io/btc-always-on-tracker/`.
8. Leave Actions enabled. The workflow runs approximately every 5 minutes and commits updated tracker data. The dashboard can be closed; the tracker continues on GitHub's runners.

## Reset history
To reset cloud history, edit `data/tracker.json` and replace its contents with:

```json
{
  "updated_at": null,
  "source": "Binance BTCUSDT spot 15m candles",
  "early": [],
  "post_lock": [],
  "last_seen_closed": 0,
  "notes": "Scheduled cloud tracker. Signals are heuristic, not calibrated probabilities."
}
```

Commit the change. The next scheduled run starts recording again.
